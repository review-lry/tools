# Chrome 插件安装和更新指南

## 📦 方案3：GitHub Pages 动态更新

### 安装步骤

#### 1. 下载插件
访问：https://review-lry.github.io/tools/dev-toolbox.zip

或直接下载：
```
wget https://review-lry.github.io/tools/dev-toolbox.zip
```

#### 2. 解压文件
解压 `dev-toolbox.zip` 到任意目录，例如：
- Windows: `C:\chrome-extensions\dev-toolbox\`
- Mac: `~/chrome-extensions/dev-toolbox/`
- Linux: `~/chrome-extensions/dev-toolbox/`

#### 3. 加载到 Chrome
1. 打开 Chrome 浏览器
2. 地址栏输入：`chrome://extensions/`
3. 开启右上角 **「开发者模式」**
4. 点击 **「加载已解压的扩展程序」**
5. 选择解压后的文件夹
6. 完成！🎉

---

## 🔄 更新机制

### 自动更新
Chrome 会在以下情况自动检查更新：
- 每次启动浏览器时
- 每 5 小时定期检查

插件会从 GitHub Pages 获取：
- `updates.xml` - 检查新版本
- `modules/config.json` - 获取功能模块更新

### 手动更新
1. 打开 `chrome://extensions/`
2. 点击左上角 **「更新」** 按钮
3. Chrome 立即检查所有扩展的更新

### 动态模块更新（方案3特色）
插件会自动从 GitHub Pages 下载功能模块：
- ✅ 无需重新安装插件
- ✅ 功能模块独立更新
- ✅ 本地缓存，离线可用

---

## 🌐 GitHub Pages 资源

| 资源 | 地址 |
|------|------|
| **首页** | https://review-lry.github.io/tools/ |
| **插件下载** | https://review-lry.github.io/tools/dev-toolbox.zip |
| **更新配置** | https://review-lry.github.io/tools/updates.xml |
| **模块配置** | https://review-lry.github.io/tools/modules/config.json |

### 功能模块
| 模块 | 说明 |
|------|------|
| [formatter.js](https://review-lry.github.io/tools/modules/formatter.js) | 智能格式化 |
| [jwt-parser.js](https://review-lry.github.io/tools/modules/jwt-parser.js) | JWT 解析 |
| [hash-generator.js](https://review-lry.github.io/tools/modules/hash-generator.js) | 哈希生成 |
| [password-generator.js](https://review-lry.github.io/tools/modules/password-generator.js) | 密码生成 |

---

## 🔧 开发者：发布新版本

### 1. 修改代码
```bash
cd chrome-extension
# 修改 popup.js 等文件...
```

### 2. 更新版本号
修改 `manifest.json`：
```json
{
  "version": "1.2.0"  // 递增版本号
}
```

### 3. 提交并推送
```bash
git add .
git commit -m "feat: 新功能描述"
git push origin main
```

### 4. 更新 GitHub Pages
```bash
# 重新打包
cd chrome-extension && zip -r ../docs/dev-toolbox.zip .

# 更新 updates.xml 版本号
# 提交到 gh-pages 分支
git checkout gh-pages-new
git checkout main -- docs/
# ... 部署步骤
```

---

## ❓ 常见问题

### 更新检查失败？
1. 检查网络是否能访问 GitHub Pages
2. 尝试手动访问：https://review-lry.github.io/tools/updates.xml
3. 检查浏览器控制台是否有错误

### 模块加载失败？
1. 插件会使用本地缓存
2. 下次启动时会自动重试
3. 可以在控制台查看具体错误

### 如何确认版本？
1. 打开插件
2. 底部显示当前版本号
3. 或查看 `manifest.json` 中的 version 字段

---

## 📊 工作流程图

```
┌─────────────────────────────────────────────────────────────┐
│                      用户安装流程                            │
├─────────────────────────────────────────────────────────────┤
│  下载 zip → 解压 → Chrome 加载扩展 → 完成                    │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│                      自动更新流程                            │
├─────────────────────────────────────────────────────────────┤
│  Chrome 启动 → 检查 updates.xml → 发现新版本 → 自动下载更新  │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│                    动态模块更新（方案3）                      │
├─────────────────────────────────────────────────────────────┤
│  插件启动 → 请求 config.json → 对比版本 → 下载新模块 → 缓存  │
└─────────────────────────────────────────────────────────────┘
```

---

## ✅ 优势总结

| 特性 | 说明 |
|------|------|
| **免费托管** | 使用 GitHub Pages，零成本 |
| **自动更新** | Chrome 原生支持 |
| **动态模块** | 功能更新无需重装 |
| **离线可用** | 本地缓存机制 |
| **开源透明** | 代码在 GitHub，可审查 |

---

_更新时间: 2026-02-28_
_版本: 1.1.0_
